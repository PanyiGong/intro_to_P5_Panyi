function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  fill(200,0,200)
  rect(50,50,50,50);
}